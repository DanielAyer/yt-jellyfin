/*
 * setup.js — first-run configuration wizard
 *
 * Jellyfin URL resolution order:
 *   1. JELLYFIN_URL from server config (/api/setup/config-defaults)
 *   2. window.location.hostname:8096 (works for cohabitating installs)
 *   3. User prompted to set JELLYFIN_URL manually if connection fails
 */

let _mode     = "jellyfin";
let _libraries = [];

/* ── API helper ──────────────────────────────────────────────────────── */
async function api(path, { method = "GET", body } = {}) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(path, opts);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}

/* ── init — load config defaults and pre-populate fields ─────────────── */
async function init() {
  try {
    const defaults = await api("/api/setup/config-defaults");

    // Jellyfin URL: config var → hostname fallback → blank
    const jellyfinUrl = defaults.jellyfin_url
      || `http://${window.location.hostname}:8096`;

    const urlInput = document.getElementById("jellyfin-url");
    urlInput.value = jellyfinUrl;
    _updateApiKeyLink(jellyfinUrl);

    if (defaults.jellyfin_api_key) {
      document.getElementById("jellyfin-api-key").value = defaults.jellyfin_api_key;
    }

    // Manual fields
    if (defaults.library_root) {
      document.getElementById("manual-library-root").value = defaults.library_root;
      _updateDbLabel(defaults.library_root);
    }
    if (defaults.db_path) {
      document.getElementById("manual-db-auto").checked = false;
      const dbInput = document.getElementById("manual-db-path");
      dbInput.value = defaults.db_path;
      dbInput.classList.remove("hidden");
    }
  } catch (_) {
    // Non-fatal — just leave fields blank
  }
}

/* ── Jellyfin URL → live API key link ────────────────────────────────── */
function _updateApiKeyLink(url) {
  const clean = url.trim().replace(/\/$/, "");
  const link  = document.getElementById("jellyfin-api-link");
  link.href   = `${clean}/web/index.html#/dashboard/keys`;
}

document.getElementById("jellyfin-url").addEventListener("input", (e) => {
  _updateApiKeyLink(e.target.value);
});

/* ── mode toggle ─────────────────────────────────────────────────────── */
document.querySelectorAll(".mode-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    _mode = btn.dataset.mode;
    document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("path-jellyfin").classList.toggle("hidden", _mode !== "jellyfin");
    document.getElementById("path-manual").classList.toggle("hidden",   _mode !== "manual");
  });
});

/* ── connect to Jellyfin ─────────────────────────────────────────────── */
document.getElementById("btn-fetch-libraries").addEventListener("click", async () => {
  const btn    = document.getElementById("btn-fetch-libraries");
  const status = document.getElementById("jellyfin-connect-status");
  const url    = document.getElementById("jellyfin-url").value.trim();
  const key    = document.getElementById("jellyfin-api-key").value.trim();

  if (!url || !key) {
    status.className = "add-status err";
    status.textContent = "Please enter both a Jellyfin URL and API key.";
    return;
  }

  btn.disabled = true;
  btn.textContent = "Connecting…";
  status.className = "add-status";
  status.textContent = "";

  try {
    const data = await api("/api/setup/jellyfin-libraries", {
      method: "POST",
      body: { jellyfin_url: url, api_key: key },
    });

    _libraries = data.libraries || [];

    if (_libraries.length === 0) {
      status.className = "add-status err";
      status.textContent = "Connected, but no library folders found. Add a library in Jellyfin first.";
      return;
    }

    // Update Jellyfin libraries link
    const jellyfinUrl = document.getElementById("jellyfin-url").value.trim().replace(/\/$/, "");
    const libLink = document.getElementById("jellyfin-libraries-link");
    if (libLink) libLink.href = `${jellyfinUrl}/web/index.html#/dashboard/libraries`;

    // Populate library dropdown
    const select = document.getElementById("jellyfin-library-select");
    select.innerHTML = "";
    _libraries.forEach(lib => {
      const opt = document.createElement("option");
      opt.value       = lib.path;
      opt.textContent = `${lib.name} — ${lib.path}`;
      select.appendChild(opt);
    });

    // Add "I don't see it" option at the end
    const notFoundOpt = document.createElement("option");
    notFoundOpt.value       = "__not_found__";
    notFoundOpt.textContent = "I don't see my library here…";
    select.appendChild(notFoundOpt);

    document.getElementById("step-library-select").classList.remove("hidden");
    document.getElementById("library-not-found-alert").classList.add("hidden");

    status.className = "add-status ok";
    status.textContent = `✓ Connected — ${_libraries.length} library folder(s) found.`;

  } catch (e) {
    status.className = "add-status err";
    // If connection failed, hint about JELLYFIN_URL config var
    const hint = e.message.includes("Could not reach")
      ? `\nIf Jellyfin is on a different machine, update the URL above or set JELLYFIN_URL in your .env file.`
      : "";
    status.textContent = `✗ ${e.message}${hint}`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Connect to Jellyfin";
  }
});

/* ── library dropdown change ─────────────────────────────────────────── */
document.getElementById("jellyfin-library-select")
  .addEventListener("change", (e) => {
    const alert  = document.getElementById("library-not-found-alert");
    const saveBtn = document.getElementById("btn-save-setup");
    if (e.target.value === "__not_found__") {
      alert.classList.remove("hidden");
      saveBtn.disabled = true;
    } else {
      alert.classList.add("hidden");
      saveBtn.disabled = false;
    }
  });

function _resolveLibraryRoot() {
  const select = document.getElementById("jellyfin-library-select");
  if (!select.value || select.value === "__not_found__") return "";
  return select.value;
}

/* ── manual DB path auto-fill ────────────────────────────────────────── */
function _updateDbLabel(root) {
  const clean = root.trim().replace(/\/$/, "");
  document.getElementById("manual-db-default-label").textContent =
    clean ? `${clean}/.ytjf.db` : "LIBRARY_ROOT/.ytjf.db";
}

document.getElementById("manual-library-root").addEventListener("input", (e) => {
  _updateDbLabel(e.target.value);
  if (document.getElementById("manual-db-auto").checked) {
    const clean = e.target.value.trim().replace(/\/$/, "");
    document.getElementById("manual-db-path").value = clean ? `${clean}/.ytjf.db` : "";
  }
});

document.getElementById("manual-db-auto").addEventListener("change", (e) => {
  const dbInput = document.getElementById("manual-db-path");
  if (e.target.checked) {
    const root = document.getElementById("manual-library-root").value.trim().replace(/\/$/, "");
    dbInput.value = root ? `${root}/.ytjf.db` : "";
    dbInput.classList.add("hidden");
  } else {
    dbInput.classList.remove("hidden");
  }
});

/* ── save configuration ──────────────────────────────────────────────── */
document.getElementById("btn-save-setup").addEventListener("click", async () => {
  const btn    = document.getElementById("btn-save-setup");
  const result = document.getElementById("setup-result");

  let library_root     = "";
  let db_path          = "";
  let jellyfin_url     = "";
  let jellyfin_api_key = "";

  if (_mode === "jellyfin") {
    library_root     = _resolveLibraryRoot();
    jellyfin_url     = document.getElementById("jellyfin-url").value.trim();
    jellyfin_api_key = document.getElementById("jellyfin-api-key").value.trim();

    if (!library_root) {
      result.className = "setup-result err";
      result.textContent = "Please connect to Jellyfin and select a library folder.";
      result.classList.remove("hidden");
      return;
    }
  } else {
    library_root = document.getElementById("manual-library-root").value.trim();
    const autoDb = document.getElementById("manual-db-auto").checked;
    db_path = autoDb
      ? `${library_root.replace(/\/$/, "")}/.ytjf.db`
      : document.getElementById("manual-db-path").value.trim();

    if (!library_root) {
      result.className = "setup-result err";
      result.textContent = "Please enter a library root folder.";
      result.classList.remove("hidden");
      return;
    }
  }

  // Auto-set DB path for Jellyfin mode
  if (!db_path && library_root) {
    db_path = `${library_root.replace(/\/$/, "")}/.ytjf.db`;
  }

  btn.disabled = true;
  btn.textContent = "Saving…";
  result.classList.add("hidden");

  try {
    const data = await api("/api/setup/save", {
      method: "POST",
      body: { library_root, db_path, jellyfin_url, jellyfin_api_key },
    });

    result.className = "setup-result ok";
    result.textContent = "✓ Configuration saved successfully.";
    result.classList.remove("hidden");
    document.getElementById("restart-block").classList.remove("hidden");
    document.getElementById("restart-block").style.display = "flex";

  } catch (e) {
    result.className = "setup-result err";
    result.textContent = `✗ ${e.message}`;
    result.classList.remove("hidden");
    btn.disabled = false;
    btn.textContent = "Save Configuration";
  }
});

/* ── copy restart command ─────────────────────────────────────────────── */
document.getElementById("btn-copy-restart")?.addEventListener("click", () => {
  const cmd = document.getElementById("restart-cmd").textContent;
  navigator.clipboard.writeText(cmd).then(() => {
    const btn = document.getElementById("btn-copy-restart");
    btn.textContent = "Copied!";
    setTimeout(() => { btn.textContent = "Copy"; }, 2000);
  }).catch(() => {
    // Fallback for browsers without clipboard API
    const el = document.createElement("textarea");
    el.value = cmd;
    document.body.appendChild(el);
    el.select();
    document.execCommand("copy");
    document.body.removeChild(el);
  });
});

/* ── init ────────────────────────────────────────────────────────────── */
init();
